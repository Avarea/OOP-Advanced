﻿public interface IBaseStat
{
    int MinDamage { get; }

    int MaxDamage { get; }

    int NumberOfSockets { get; }
}

