﻿public interface IGem : IAdditionalStats
{
    string Name { get; }
}

