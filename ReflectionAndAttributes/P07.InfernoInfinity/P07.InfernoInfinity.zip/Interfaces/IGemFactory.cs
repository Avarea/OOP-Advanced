﻿public interface IGemFactory
{
    IGem CreateGem(string name, Clarity clarity);
}

